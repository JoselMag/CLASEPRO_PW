-- Programa: Hola mundo en Lua
-- Ejecutar: lua main.lua
print("Hola mundo") -- Imprime y agrega newline
