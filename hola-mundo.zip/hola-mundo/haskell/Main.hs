-- Programa: Hola mundo en Haskell
-- Ejecutar rapido: runhaskell Main.hs  (o compilar con ghc)
main = putStrLn "Hola mundo"  -- Accion IO que imprime
