<?php
// Programa: Hola mundo en PHP
// Ejecutar: php index.php
echo "Hola mundo\n"; // Imprime y añade salto de linea
?>