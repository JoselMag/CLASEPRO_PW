# Programa: Hola mundo en PowerShell
# Ejecutar: pwsh -NoLogo -File ./hello.ps1
Write-Output "Hola mundo"  # Envia la cadena al pipeline/salida
