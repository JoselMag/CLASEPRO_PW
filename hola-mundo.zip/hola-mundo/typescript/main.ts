// Programa: Hola mundo en TypeScript
// Ejecutar: ts-node main.ts  (o compilar con tsc y ejecutar con node)
console.log("Hola mundo"); // Igual que en JS tras transpilar
