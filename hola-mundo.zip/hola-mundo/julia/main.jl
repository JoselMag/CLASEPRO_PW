# Programa: Hola mundo en Julia
# Ejecutar: julia main.jl
println("Hola mundo")  # Imprime con salto de linea
