#!/usr/bin/env bash
# Programa: Hola mundo en Bash
# Ejecutar: bash hello.sh  (o dar permisos y ./hello.sh)
echo "Hola mundo"  # Escribe en stdout
