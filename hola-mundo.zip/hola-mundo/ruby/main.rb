# Programa: Hola mundo en Ruby
# Ejecutar: ruby main.rb
puts "Hola mundo"  # puts añade salto de linea
