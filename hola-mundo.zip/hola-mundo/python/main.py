# Programa: Hola mundo en Python
# Ejecutar: python3 main.py
print("Hola mundo")  # Imprime en salida estandar
