// Programa: Hola mundo en Dart
// Ejecutar: dart run main.dart
void main() {
  print("Hola mundo"); // Imprime en stdout
}
