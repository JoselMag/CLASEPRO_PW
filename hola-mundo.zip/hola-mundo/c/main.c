// Programa: Hola mundo en C
// Compilar: gcc main.c -o app
#include <stdio.h>        // puts esta en stdio.h

int main(void){
    puts("Hola mundo");   // Escribe la cadena y un salto de linea
    return 0;             // Indica fin correcto
}
