' Programa: Hola mundo en VB.NET
' Ejecutar (proy. rapido): dotnet new console -lang VB -n app && dotnet run --project app
Module M
  Sub Main()
    Console.WriteLine("Hola mundo") ' Imprime en stdout
  End Sub
End Module
