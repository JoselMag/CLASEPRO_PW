# Programa: Hola mundo en Elixir
# Ejecutar: elixir main.exs
IO.puts "Hola mundo"  # Imprime con newline
