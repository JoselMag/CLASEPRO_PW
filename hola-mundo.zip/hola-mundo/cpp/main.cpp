// Programa: Hola mundo en C++
// Compilar: g++ main.cpp -o app
#include <iostream>       // std::cout

int main(){
    std::cout << "Hola mundo\n"; // Imprime y termina con \n
    return 0;                     // Fin correcto
}
