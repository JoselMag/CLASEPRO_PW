// Programa: Hola mundo en Swift (CLI)
// Ejecutar: swift main.swift (o compilar con swiftc)
print("Hola mundo") // Imprime en stdout
