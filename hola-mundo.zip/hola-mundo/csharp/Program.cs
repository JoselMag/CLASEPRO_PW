// Programa: Hola mundo en C# (.NET)
// Ejecutar rapido: dotnet new console -n app && dotnet run --project app
using System;

class Program {
    static void Main(){
        Console.WriteLine("Hola mundo"); // Escribe en stdout
    }
}
