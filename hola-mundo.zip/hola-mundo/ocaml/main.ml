(* Programa: Hola mundo en OCaml *)
(* Ejecutar: ocaml main.ml  o compilar a nativo con ocamlopt *)
print_endline "Hola mundo"  (* Imprime y anade salto de linea *)
