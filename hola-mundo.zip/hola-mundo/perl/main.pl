# Programa: Hola mundo en Perl
# Ejecutar: perl main.pl
print "Hola mundo\n"; # Imprime con salto de linea
