% Programa: Hola mundo en MATLAB/Octave
% Ejecutar: octave main.m  (o en MATLAB)
disp('Hola mundo') % Muestra cadena por pantalla
