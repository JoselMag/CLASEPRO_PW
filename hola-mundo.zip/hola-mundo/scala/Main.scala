// Programa: Hola mundo en Scala
// Ejecutar: scala Main.scala  (o compilar con scalac)
object Main {
  def main(args: Array[String]): Unit = {
    println("Hola mundo") // Imprime en stdout
  }
}
