-- Consulta de ejemplo en SQL (p. ej. psql o sqlite)
-- Ejecutar: psql -c "\i hello.sql"  o  sqlite3 ':memory:' '.read hello.sql'
SELECT 'Hola mundo' AS saludo;
