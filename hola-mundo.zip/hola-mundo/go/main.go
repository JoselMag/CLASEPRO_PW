// Programa: Hola mundo en Go
// Ejecutar: go run main.go  (o compilar con go build)
package main

import "fmt" // Paquete de formato e I/O

func main(){
    fmt.Println("Hola mundo") // Imprime cadena con salto de linea
}
