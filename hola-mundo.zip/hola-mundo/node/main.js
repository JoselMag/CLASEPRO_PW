// Programa: Hola mundo en Node.js
// Ejecutar: node main.js
console.log("Hola mundo"); // Escribe en consola
