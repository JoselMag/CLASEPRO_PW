#!/usr/bin/env Rscript
# Programa: Hola mundo en R
# Ejecutar: Rscript main.R
cat("Hola mundo\n")  # Imprime sin comillas
