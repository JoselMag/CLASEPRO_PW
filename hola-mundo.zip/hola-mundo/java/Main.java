// Programa: Hola mundo en Java
// Compilar: javac Main.java  Ejecutar: java Main
class Main {
    public static void main(String[] args){
        System.out.println("Hola mundo"); // Imprime con salto de linea
    }
}
