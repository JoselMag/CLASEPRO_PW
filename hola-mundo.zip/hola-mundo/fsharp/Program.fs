// Programa: Hola mundo en F#
// Ejecutar: dotnet fsi Program.fs  (o proyecto .NET)
printfn "Hola mundo"  // Imprime con salto de linea
