// Programa: Hola mundo en Rust
// Compilar: rustc main.rs -o app  (o usar cargo)
// println! es un macro que escribe en stdout
fn main() {
    println!("Hola mundo");
}
