// Programa: Hola mundo en Kotlin
// Compilar/ejecutar: kotlinc Main.kt -include-runtime -d app.jar && java -jar app.jar

fun main(){
    println("Hola mundo") // Imprime con salto de linea
}
